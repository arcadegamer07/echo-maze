'use client'

import { useEffect, useMemo, useState, type ReactNode } from 'react'
import {
  Activity,
  AlertTriangle,
  ArrowDownToLine,
  Check,
  ChevronRight,
  CircleStop,
  Download,
  Eye,
  FileCheck2,
  Gauge,
  Layers3,
  RotateCcw,
  ScanLine,
  Share2,
} from 'lucide-react'
import { EchoMazeSocket } from '@/lib/echo-maze-socket'
import {
  baselineGrid,
  currentGrid,
  diffGrid,
  diffZones,
  pose,
  runMetadata,
  scores,
  telemetry,
  type RunState,
} from '@/lib/demo-model'

type View = 'overview' | 'analysis' | 'report'
const socket = new EchoMazeSocket()

function NavButton({
  view,
  active,
  icon: Icon,
  label,
  onClick,
}: {
  view: View
  active: boolean
  icon: typeof Activity
  label: string
  onClick: (view: View) => void
}) {
  return (
    <button className={`nav-button ${active ? 'active' : ''}`} onClick={() => onClick(view)}>
      <Icon />
      <span>{label}</span>
      {active && <ChevronRight size={12} className="nav-chevron" />}
    </button>
  )
}

function Panel({
  title,
  code,
  children,
  className = '',
}: {
  title: string
  code?: string
  children: ReactNode
  className?: string
}) {
  return (
    <section className={`panel ${className}`}>
      <header className="panel-head">
        <h2 className="panel-title">{title}</h2>
        {code && <span className="panel-code">{code}</span>}
      </header>
      {children}
    </section>
  )
}

function MapGrid({
  mode = 'occupancy',
  interpolation = 0.72,
  compact = false,
  ghost = false,
}: {
  mode?: 'occupancy' | 'diff'
  interpolation?: number
  compact?: boolean
  ghost?: boolean
}) {
  const [focused, setFocused] = useState<number | null>(null)
  const cells =
    mode === 'diff'
      ? diffGrid
      : currentGrid.map((value, i) => baselineGrid[i] * (1 - interpolation) + value * interpolation)
  const renderCells = (values: number[], layer: string) => (
    <div className={`map-grid ${layer}`} role="grid" aria-label={`${mode} map`}>
      {values.map((value, index) => {
        const hot = mode === 'diff'
        const color = hot
          ? `rgba(${Math.round(120 + value * 135)}, ${Math.round(210 - value * 124)}, ${Math.round(222 - value * 130)}, ${Math.min(0.98, 0.3 + value * 0.72)})`
          : `rgba(${Math.round(64 + value * 150)}, ${Math.round(190 + value * 55)}, ${Math.round(212 + value * 40)}, ${Math.min(0.96, 0.24 + value * 0.82)})`
        return (
          <div
            key={index}
            className={`map-cell ${focused === index ? 'focused' : ''}`}
            style={{ backgroundColor: color }}
            onMouseEnter={() => setFocused(index)}
            onMouseLeave={() => setFocused(null)}
            onFocus={() => setFocused(index)}
            tabIndex={0}
            role="gridcell"
            aria-label={`cell ${index + 1}, value ${Math.round(value * 100)}%`}
          />
        )
      })}
    </div>
  )
  return (
    <div className={`map-shell ${compact ? 'compact-map' : ''}`}>
      {ghost && mode === 'occupancy' && renderCells(baselineGrid, 'ghost-layer')}
      {renderCells(cells, 'live-layer')}
      {mode === 'occupancy' && (
        <svg className="point-cloud" viewBox="0 0 160 100" aria-label="registered point cloud">
          {Array.from({ length: 38 }, (_, index) => {
            const x = ((index * 37) % 150) + 5
            const y = ((index * 53) % 88) + 6
            return (
              <circle
                key={index}
                cx={x}
                cy={y}
                r={index % 6 === 0 ? 1.1 : 0.65}
                fill={index % 5 === 0 ? '#cbb8ff' : '#7fe9f6'}
                opacity={index % 5 === 0 ? 0.95 : 0.7}
              />
            )
          })}
        </svg>
      )}
      {mode === 'occupancy' && (
        <>
          <div className="map-rover" aria-label="Rover pose" />
          <div className="map-legend">
            <span>
              <i className="legend-swatch" style={{ background: '#3fd4ec' }} />
              occupied
            </span>
            <span>
              <i className="legend-swatch" style={{ background: '#1d4652' }} />
              free
            </span>
          </div>
        </>
      )}
      {mode === 'diff' && (
        <div className="map-legend">
          <span>
            <i className="legend-swatch" style={{ background: '#ff6f6c' }} />
            change intensity
          </span>
        </div>
      )}
    </div>
  )
}

function Header({ view, state, onPrivacy }: { view: View; state: RunState; onPrivacy: () => void }) {
  const titles: Record<View, [string, string]> = {
    overview: ['LIVE INSPECTION', 'Structural verification cockpit'],
    analysis: ['MAP / ANALYSIS', 'Baseline comparison and anomaly evidence'],
    report: ['FINAL REPORT', 'Judge-ready structural verification summary'],
  }
  return (
    <div className="view-heading">
      <div>
        <div className="eyebrow">ECHO MAZE / CSE-4</div>
        <h1 className="page-title">{titles[view][0]}</h1>
        <p className="page-subtitle">{titles[view][1]} · telemetry-backed demo surface for MAZE-ALPHA.</p>
      </div>
      <div>
        <div className={`run-chip ${state === 'VERIFYING' ? 'review' : ''}`}>
          <span className="live-dot" />
          {state === 'IDLE'
            ? 'READY FOR COMMAND'
            : state === 'STOPPED'
              ? 'RUN HALTED'
              : `${state} · ${runMetadata.id}`}
        </div>
        <button className="top-action" style={{ marginTop: 8, float: 'right' }} onClick={onPrivacy}>
          CONNECTION NOTICE
        </button>
      </div>
    </div>
  )
}

function ControlPanel({
  state,
  progress,
  onCommand,
}: {
  state: RunState
  progress: number
  onCommand: (command: 'learn' | 'verify' | 'stop' | 'reset') => void
}) {
  const active = state === 'LEARNING' || state === 'VERIFYING'
  return (
    <Panel title="Run controls" code="COMMAND DECK">
      <div className="panel-body">
        <div className="command-row">
          <button className="command" disabled={active} onClick={() => onCommand('learn')}>
            <ScanLine size={16} className="command-icon" />
            <div>
              <div className="command-label">LEARN ENVIRONMENT</div>
              <div className="command-caption">Capture baseline geometry</div>
            </div>
          </button>
          <button className="command verify" disabled={active} onClick={() => onCommand('verify')}>
            <FileCheck2 size={16} className="command-icon" />
            <div>
              <div className="command-label">VERIFY STRUCTURE</div>
              <div className="command-caption">Compare against baseline</div>
            </div>
          </button>
        </div>
        <button className="stop-button" disabled={!active} onClick={() => onCommand('stop')}>
          <CircleStop size={12} style={{ verticalAlign: 'middle', marginRight: 7 }} />
          STOP CURRENT RUN
        </button>
        <div className="state-line">
          <span>mission state</span>
          <strong>{state}</strong>
        </div>
        <div className="progress-track">
          <div className="progress-fill" style={{ width: `${progress}%` }} />
        </div>
        <div className="progress-meta">
          <span>ROUTE PROGRESS</span>
          <span>{progress.toFixed(0)}%</span>
        </div>
        {state === 'STOPPED' && (
          <button
            className="top-action"
            style={{ width: '100%', marginTop: 14 }}
            onClick={() => onCommand('reset')}
          >
            <RotateCcw size={11} style={{ verticalAlign: 'middle', marginRight: 6 }} />
            RESET DEMO STATE
          </button>
        )}
      </div>
    </Panel>
  )
}

function TelemetryPanel() {
  const rows = [
    ['motor state', telemetry.motorState],
    ['drive output', `${telemetry.leftMotor}% L / ${telemetry.rightMotor}% R`],
    ['IMU accel', telemetry.accel],
    ['IMU gyro', telemetry.gyro],
    ['ultrasonic', `${telemetry.ultrasonic} cm`],
    ['IR reflectance', `${telemetry.ir} raw`],
    ['temperature', `${telemetry.temperature} °C`],
  ]
  return (
    <Panel title="Telemetry snapshot" code="10 HZ / DEMO">
      <div className="panel-body telemetry-list telemetry-grid">
        {rows.map(([name, value]) => (
          <div className="telemetry-item" key={name}>
            <span className="telemetry-name">{name}</span>
            <span className="telemetry-value">{value}</span>
          </div>
        ))}
      </div>
    </Panel>
  )
}

function ScorePanel() {
  const rows: Array<[string, number, string]> = [
    ['geometry', scores.geometry, '#4fe0f5'],
    ['tilt', scores.tilt, '#b9a5ff'],
    ['vibration', scores.vibration, '#ffd15c'],
    ['thermal deviation', scores.thermal, '#ff8f8c'],
  ]
  return (
    <Panel title="Structural anomaly" code="WEIGHTED EVIDENCE">
      <div className="panel-body">
        <div className="score-list">
          {rows.map(([label, value, color]) => (
            <div className="score-row" key={String(label)}>
              <span className="score-label">{label}</span>
              <div className="score-track">
                <div className="score-bar" style={{ width: `${Number(value) * 2.5}%`, backgroundColor: color }} />
              </div>
              <span className="score-number">{value}</span>
            </div>
          ))}
        </div>
        <div className="score-summary">
          <div>
            <div className="score-total">{scores.total}</div>
            <div className="zones">combined change score / 100</div>
          </div>
          <div className="severity">
            MODERATE
            <br />
            <span style={{ color: 'hsl(var(--muted-foreground))' }}>2 zones flagged</span>
          </div>
        </div>
      </div>
    </Panel>
  )
}

function Overview({
  state,
  progress,
  onCommand,
  onView,
}: {
  state: RunState
  progress: number
  onCommand: (command: 'learn' | 'verify' | 'stop' | 'reset') => void
  onView: (view: View) => void
}) {
  const [ghostOn, setGhostOn] = useState(true)
  return (
    <>
      <div className="overview-primary">
        <Panel title="Occupancy / point cloud" code="LIVE MAP" className="map-panel">
          <div className="panel-body" style={{ padding: 0 }}>
            <div
              style={{
                padding: '10px 16px',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                font: '9px var(--app-font-mono)',
                color: 'hsl(var(--muted-foreground))',
              }}
            >
              <span>REGISTERED POINT CLOUD · 1,842 PTS</span>
              <label className="ghost-toggle">
                <input type="checkbox" checked={ghostOn} onChange={(event) => setGhostOn(event.target.checked)} /> GHOST
                BASELINE
              </label>
            </div>
            <MapGrid ghost={ghostOn} />
            <div
              style={{
                padding: '10px 16px',
                display: 'flex',
                justifyContent: 'space-between',
                font: '9px var(--app-font-mono)',
                color: 'hsl(var(--muted-foreground))',
              }}
            >
              <span>
                POSE {pose.x.toFixed(2)}m / {pose.y.toFixed(2)}m · {pose.heading}°
              </span>
              <span style={{ color: '#7bf0bf' }}>CONFIDENCE {pose.confidence}%</span>
            </div>
          </div>
        </Panel>
        <div className="overview-rail">
          <ControlPanel state={state} progress={progress} onCommand={onCommand} />
          <ScorePanel />
        </div>
      </div>
      <div className="overview-secondary">
        <TelemetryPanel />
        <Panel title="Baseline / current evidence" code="RUN PAIR">
          <div className="panel-body">
            <div className="metric-grid">
              <div className="metric">
                <div className="metric-label">baseline</div>
                <div className="metric-value violet">
                  MAZE-ALPHA <span className="metric-unit">v.01</span>
                </div>
              </div>
              <div className="metric">
                <div className="metric-label">current run</div>
                <div className="metric-value cyan">
                  RUN-0427 <span className="metric-unit">live</span>
                </div>
              </div>
              <div className="metric">
                <div className="metric-label">map confidence</div>
                <div className="metric-value">
                  96.2<span className="metric-unit">%</span>
                </div>
              </div>
              <div className="metric">
                <div className="metric-label">points registered</div>
                <div className="metric-value amber">1,842</div>
              </div>
            </div>
            <button className="export-button" onClick={() => onView('analysis')}>
              <Eye size={13} />
              OPEN COMPARISON WORKSPACE
            </button>
          </div>
        </Panel>
      </div>
      <div className="footer-strip">
        <span>
          <Check size={11} style={{ verticalAlign: 'middle', marginRight: 5 }} />
          LOCAL DEMO MODEL ACTIVE
        </span>
        <span>WS BOUNDARY READY · LAST PACKET {runMetadata.startedAt}</span>
      </div>
    </>
  )
}

function Analysis() {
  const [time, setTime] = useState(72)
  return (
    <div className="analysis-layout">
      <div className="analysis-main">
        <Panel title="Time-machine map" code="INTERPOLATED OCCUPANCY">
          <div className="panel-body" style={{ padding: 0 }}>
            <MapGrid interpolation={time / 100} />
            <div className="slider-wrap">
              <div className="slider-header">
                <span>MAP STATE</span>
                <strong>{time}% CURRENT</strong>
              </div>
              <input type="range" min="0" max="100" value={time} onChange={(event) => setTime(Number(event.target.value))} />
              <div className="time-labels">
                <span>BASELINE · 14:09:34</span>
                <span>VERIFY · 14:32:08</span>
              </div>
            </div>
          </div>
        </Panel>
      </div>
      <div className="analysis-side">
        <Panel title="Diff heatmap" code="Δ OCCUPANCY">
          <div className="panel-body" style={{ padding: 0 }}>
            <MapGrid mode="diff" compact />
            <div style={{ padding: '12px 16px' }} className="heat-legend">
              <span>LOW</span>
              <div className="heat-gradient" />
              <span>HIGH</span>
            </div>
          </div>
        </Panel>
        <Panel title="Critical zones" code="3 FLAGS">
          <div className="panel-body">
            {diffZones.map((zone) => (
              <div className="zone-item" key={zone.id}>
                <div className="zone-id">
                  {zone.id} · {zone.severity}
                </div>
                <div className="zone-copy">
                  {zone.label} <span style={{ color: '#ffc978' }}>{zone.delta}</span>
                </div>
              </div>
            ))}
          </div>
        </Panel>
      </div>
    </div>
  )
}

function Report({ onExport }: { onExport: () => void }) {
  return (
    <>
      <div className="report-banner">
        <AlertTriangle size={24} />
        <div>
          <strong>INSPECTION REQUIRED</strong>
          <p>
            Structure change exceeds the CSE-4 review threshold. Inspect flagged zones before clearing MAZE-ALPHA for the
            next run.
          </p>
        </div>
      </div>
      <div className="report-grid">
        <Panel title="Verification result" code={runMetadata.id}>
          <div className="panel-body">
            <div className="similarity">
              <div className="similarity-ring">
                <div className="similarity-number">
                  92.4<small>MAP SIMILARITY</small>
                </div>
              </div>
              <div className="report-stats">
                <div className="report-stat">
                  <span>geometry agreement</span>
                  <strong>88.1%</strong>
                </div>
                <div className="report-stat">
                  <span>route coverage</span>
                  <strong>96.2%</strong>
                </div>
                <div className="report-stat">
                  <span>points compared</span>
                  <strong>1,842 / 1,901</strong>
                </div>
                <div className="report-stat">
                  <span>critical zones</span>
                  <strong className="critical">2 / 3</strong>
                </div>
              </div>
            </div>
            <button className="export-button" onClick={onExport}>
              <Download size={13} />
              EXPORT DEMO REPORT <Share2 size={13} />
            </button>
          </div>
        </Panel>
        <Panel title="Evidence record" code="RUN METADATA">
          <div className="panel-body info-list">
            <div className="info-row">
              <span>run identifier</span>
              <strong>{runMetadata.id}</strong>
            </div>
            <div className="info-row">
              <span>verification mode</span>
              <strong>{runMetadata.mode}</strong>
            </div>
            <div className="info-row">
              <span>route definition</span>
              <strong>{runMetadata.route}</strong>
            </div>
            <div className="info-row">
              <span>captured</span>
              <strong>{runMetadata.startedAt}</strong>
            </div>
            <div className="info-row">
              <span>baseline fingerprint</span>
              <strong>ALPHA-7F2C</strong>
            </div>
            <div className="info-row">
              <span>anomaly score</span>
              <strong className="critical">31 / MODERATE</strong>
            </div>
          </div>
        </Panel>
      </div>
    </>
  )
}

export function EchoMazeDashboard() {
  const [view, setView] = useState<View>('overview')
  const [state, setState] = useState<RunState>('IDLE')
  const [progress, setProgress] = useState(72)
  const [privacyOpen, setPrivacyOpen] = useState(true)
  const [commandNote, setCommandNote] = useState('Ready')
  const nav = [
    { view: 'overview' as View, icon: Gauge, label: 'Live inspection' },
    { view: 'analysis' as View, icon: Layers3, label: 'Map / analysis' },
    { view: 'report' as View, icon: FileCheck2, label: 'Final report' },
  ]
  useEffect(() => {
    if (state !== 'LEARNING' && state !== 'VERIFYING') return
    const timer = window.setInterval(
      () =>
        setProgress((value) => {
          if (value >= 100) {
            setState('COMPLETE')
            setCommandNote('Route complete · evidence ready')
            return 100
          }
          return Math.min(100, value + 2)
        }),
      750,
    )
    return () => window.clearInterval(timer)
  }, [state])
  const command = (next: 'learn' | 'verify' | 'stop' | 'reset') => {
    socket.send(next)
    if (next === 'learn') {
      setState('LEARNING')
      setProgress(14)
      setCommandNote('Baseline capture started')
    }
    if (next === 'verify') {
      setState('VERIFYING')
      setProgress(72)
      setCommandNote('Verification route active')
    }
    if (next === 'stop') {
      setState('STOPPED')
      setCommandNote('Run halted by operator')
    }
    if (next === 'reset') {
      setState('IDLE')
      setProgress(72)
      setCommandNote('Ready')
    }
  }
  const statusText = useMemo(() => (state === 'IDLE' ? 'Awaiting command' : commandNote), [commandNote, state])
  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark" />
          <div className="brand-wordmark">ECHO MAZE</div>
          <div className="brand-sub">CSE-4</div>
        </div>
        <div className="top-meta">
          <span className="connection">
            <span className="live-dot" />
            DEMO LINK
          </span>
          <span className="top-timestamp">14:32:08 UTC · PACKET 1842</span>
          <button className="top-action" onClick={() => setView('report')}>
            REPORT <ArrowDownToLine size={10} style={{ verticalAlign: 'middle', marginLeft: 5 }} />
          </button>
        </div>
      </header>
      <div className="mobile-nav">
        {nav.map((item) => (
          <NavButton key={item.view} {...item} active={view === item.view} onClick={setView} />
        ))}
      </div>
      <div className="body-layout">
        <aside className="sidebar">
          <div className="nav-kicker">INSPECTION CONSOLE</div>
          <nav className="nav-list">
            {nav.map((item) => (
              <NavButton key={item.view} {...item} active={view === item.view} onClick={setView} />
            ))}
          </nav>
          <div className="sidebar-footer">
            <div className="side-unit">
              ROVER UNIT
              <br />
              <strong>EM-RVR-01</strong>
            </div>
            <div className="side-unit" style={{ marginTop: 12 }}>
              ENVIRONMENT
              <br />
              <strong>MAZE-ALPHA / BASELINE</strong>
            </div>
          </div>
        </aside>
        <main className="main">
          <Header view={view} state={state} onPrivacy={() => setPrivacyOpen(true)} />
          {view === 'overview' && (
            <Overview state={state} progress={progress} onCommand={command} onView={setView} />
          )}
          {view === 'analysis' && <Analysis />}
          {view === 'report' && <Report onExport={() => setCommandNote('Report staged for export')} />}
          <div
            style={{
              position: 'fixed',
              right: 18,
              bottom: 18,
              color: 'hsl(var(--muted-foreground))',
              font: '9px var(--app-font-mono)',
              pointerEvents: 'none',
            }}
          >
            <Activity size={11} style={{ verticalAlign: 'middle', marginRight: 5 }} />
            {statusText}
          </div>
        </main>
      </div>
      {privacyOpen && (
        <div className="modal-shade">
          <div className="privacy-modal" role="dialog" aria-labelledby="privacy-title">
            <h2 id="privacy-title">Your inspection data stays local.</h2>
            <p>
              Echo Maze is running in demo mode. Telemetry, occupancy grids, and verification evidence are held in this
              browser surface only. No rover data leaves this CSE-4 console while the live connection is disconnected.
            </p>
            <button onClick={() => setPrivacyOpen(false)}>
              <Check size={12} style={{ verticalAlign: 'middle', marginRight: 6 }} />
              CONTINUE TO CONSOLE
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
